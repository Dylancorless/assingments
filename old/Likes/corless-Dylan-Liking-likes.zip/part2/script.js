var amount = 9
var amountElement = document.querySelector("#amount");

console.log(amountElement);

function add1(){
    amount++;
    amountElement.innerText = amount;
    console.log(amount);
    
}

var amount2 = 12
var amountElement2 = document.querySelector("#amount2");

console.log(amountElement2);

function add2(){
    amount2++;
    amountElement2.innerText = amount2;
    console.log(amount2);
    
}

var amount3 = 12
var amountElement3 = document.querySelector("#amount3");

console.log(amountElement3);

function add3(){
    amount3++;
    amountElement3.innerText = amount3;
    console.log(amount3);
    
}